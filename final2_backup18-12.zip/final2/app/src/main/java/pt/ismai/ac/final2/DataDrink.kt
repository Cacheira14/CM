package pt.ismai.ac.final2

data class DataDrink(
    val idDrink: String,
    val strDrink: String,
    val strCategory: String,
    val strInstructions: String,
    val strDrinkThumb: String
)