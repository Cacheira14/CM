package pt.ismai.ac.final2

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CocktailViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    val drinkName: TextView = itemView.findViewById(R.id.drink_name)
    val drinkImage: TextView = itemView.findViewById(R.id.drink_image)

    fun bind(DataDrink: DataDrink) {
        drinkName.text = DataDrink.strDrink
        drinkImage.text = DataDrink.strDrinkThumb
    }
}
