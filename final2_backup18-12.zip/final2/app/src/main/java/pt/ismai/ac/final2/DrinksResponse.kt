package pt.ismai.ac.final2

import com.google.gson.Gson

data class DrinksResponse(val drinks: List<DataDrink>)

fun parseJson(json: String): DrinksResponse {
    val gson = Gson()
    return gson.fromJson(json, DrinksResponse::class.java)
}