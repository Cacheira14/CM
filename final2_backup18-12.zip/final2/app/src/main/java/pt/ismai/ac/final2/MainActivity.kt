package pt.ismai.ac.final2

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import pt.ismai.ac.final2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var text_view: TextView

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        text_view = binding.txtView
        Thread {
            val client = OkHttpClient()

            val request = Request.Builder()
                .url("https://www.thecocktaildb.com/api/json/v1/1/filter.php?c=Ordinary_Drink")
                .build()

            try {
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                val drinksResponse = parseJson(responseBody ?: "")
                val drinks = drinksResponse.drinks

                val stringBuilder = StringBuilder()
                for (drink in drinks) {
                    stringBuilder.append(drink.strDrink)
                    stringBuilder.append("\n")
                }

                runOnUiThread {
                    text_view.text = stringBuilder.toString()
                }
            } catch (e: IOException) {
                // Handle the exception
            }
        }.start()
    }
}